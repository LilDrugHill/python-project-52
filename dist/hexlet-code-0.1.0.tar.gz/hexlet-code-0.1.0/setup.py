# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['task_manager']

package_data = \
{'': ['*'], 'task_manager': ['templates/*']}

install_requires = \
['Django>=4.1.1,<5.0.0',
 'django-on-heroku>=1.1.2,<2.0.0',
 'gunicorn>=20.1.0,<21.0.0']

setup_kwargs = {
    'name': 'hexlet-code',
    'version': '0.1.0',
    'description': '',
    'long_description': None,
    'author': 'LilDrugHill',
    'author_email': 'smookigrow@icloud.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.10,<4.0',
}


setup(**setup_kwargs)
